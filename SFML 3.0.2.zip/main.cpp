﻿#include <SFML/Graphics.hpp>

int main()
{

    sf::VideoMode vm;
    vm.size = { 800, 600 };

    sf::RenderWindow window(vm, "{NAME WINDOW}");

	// data initialization here 

    while (window.isOpen())
    {
        while (auto event = window.pollEvent())
        {
            if (event->is<sf::Event::Closed>())
                window.close();

            if (const auto* keyPressed = event->getIf<sf::Event::KeyPressed>()) {
                if (keyPressed->code == sf::Keyboard::Key::Escape) window.close();
            }
            if (const auto* mouseButtonPressed = event->getIf<sf::Event::MouseButtonPressed>()) {
                if (mouseButtonPressed->button == sf::Mouse::Button::Left) {
                    // handle left mouse button press
				}
            }

        }

		// programm loop body here

        window.clear();

		//draw your stuff here

        window.display();
    }

    return 0;
}
